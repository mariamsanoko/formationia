/// <reference types="astro/client" />
declare namespace App {
  interface Locals {
    email: string;
  }
}
