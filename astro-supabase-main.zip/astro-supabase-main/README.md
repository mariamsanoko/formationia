# Astro and Supabase demo

This demo uses [Astro](https://astro.build) and [Supabase](https://supabase.com) to create a simple app showcasing the use of Supabase's auth and database features.

Try a [live demo](https://astro-supabase-auth.vercel.app/).
